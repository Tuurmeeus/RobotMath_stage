var config = {
    style: 'mapbox://styles/hbenzz/clalb131g001214qulig6uzbu',
    accessToken: 'pk.eyJ1IjoiaGJlbnp6IiwiYSI6ImNsYTB3cHE5YjAxcnIzb29qYWNrcXlxbnYifQ.8SX1brHjGaH-xtxEt1uywg',
    showMarkers: false,
    markerColor: '#3FB1CE',
    //projection: 'equirectangular',
    //Read more about available projections here
    //https://docs.mapbox.com/mapbox-gl-js/example/projections/
    inset: true,
    theme: 'dark',
    use3dTerrain: false, //set true for enabling 3D maps.
    auto: false,
    title: 'What traffic accidents tell us about Brussels',
    subtitle: '',
    byline: '',
    footer: 'Data source: <a href="https://ibsa.brussels/themes/securite/securite-routiere" target="_blank">IBSA.Brussels</a> & the Belgian Federal Police. <br> Created using <a href="https://github.com/mapbox/storytelling" target="_blank">Mapbox Storytelling</a> template.',
    chapters: [

      {
          id: 'Intro',
          alignment: 'fully',
          hidden: false,
          title: 'Introduction',
          image: '',
          description: 'Everyday, we make decisions to reach our daily destinations. We take the bike, the car, public transportation and cross several crosswalks. But all those expose us to the danger of traffic. Traffic safety is therefore of great importance in our lives, yet remains difficult to manage and are still on the forefront of several political discussions. \n The piétonnier and the Ville 30 are decisions that are still discussed and debated nowadays, without knowing for a fact the impact they may have. So let’s see where the issue is situated. Where do accidents with injured and or deaths occur? What do they tell us about the roads of the Brussels Region? Is there a way to find solutions by analyzing them? This is what we’ll try to figure out by analyzing the data of 2021 while trying to make them tell us the story of traffic safety in our capital.',
          location: {
            center: [4.35397, 50.84169],
            zoom: 11,
            pitch: 15.65,
            bearing: 0.00
          },
          mapAnimation: 'flyTo',
          rotateAnimation: false,
          callback: '',
          onChapterEnter: [
          ],
          onChapterExit: [
          ]
      },
        {
            id: 'CommunesIntro',
            alignment: 'right',
            hidden: false,
            title: '',
            image: '',
            description: 'As you may know, the Brussels Region is composed of 19 communes (communes), all managed by one mayor. The management of each road depends on its situation and can be the responsibility of a commune or the Brussels-Capital Region.',
            location: {
              center: [4.35397, 50.84169],
              zoom: 11,
              pitch: 15.65,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
               {
                 layer: 'Communes',
                 opacity: 1,
               },
               {
                 layer: 'Communes21',
                 opacity: 0,

               },
               {
                 layer: 'Bxl Cap Ixl',
                 opacity: 0,
               },
               {
                 layer: 'Ixelles',
                 opacity: 0,
               },
               {
                 layer: 'Accidents',
                 opacity: 0,
               },
               {
                 layer: 'Zones Police',
                 opacity: 0,
               },
               {
                 layer: 'Pietonnier',
                 opacity: 0,
               },
               {
                 layer: 'flagey',
                 opacity: 0,
               },
            ],
            onChapterExit: [
              {
                layer: 'Communes',
                opacity: 0.3,
              }
            ]
        },
        {
            id: 'PZIntro',
            alignment: 'right',
            hidden: false,
            title: 'Police Zones',
            image: '',
            description: 'The 19 communes of the Brussels-Capital Region are divided into 7 Police Zones. Each zone is then managed by the mayors of the different communes composing them. Once an accident occurs it will also depend on its position to be handle by a Local Police Zone (communal level) or the Federal Police (Regional level). This can sometimes be confusing, but data related to traffic accidents is still centralized by the Federal Police. This data will be at the center of our story.',
            location: {
              center: [4.35397, 50.84169],
              zoom: 11,
              pitch: 15.65,
              bearing: 0.00
                // flyTo additional controls-
                // These options control the flight curve, making it move
                // slowly and zoom out almost completely before starting
                // to pan.
                //speed: 2, // make the flying slow
                //curve: 1, // change the speed at which it zooms out
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Zones Police',
                opacity: 1,
              }
            ],
            onChapterExit: [
              {
                layer: 'Zones Police',
                opacity: 0.4,
              }
            ]
        },
        {
            id: 'PietonnierIntro',
            alignment: 'right',
            hidden: false,
            title: 'Pietonnier',
            image: '',
            description: 'In the commune of Brussels-Capitale, you’ll find one major pedestrian zone. This pedestrian zone (Pietonnier) was first introduced in 2015 after protests of residents demanding a safer and calmer city center. \n Now how does one pedestrian zone potentially impact traffic safety? Is there a link between an auto-free zone and number of accidents with injuries. If not, what would be the cause of traffic accidents in Brussels? Those are the question we will try to answer with this story.',
            location: {
              center: [4.35397, 50.84169],
              zoom: 11.56,
              pitch: 15.65,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Pietonnier',
                opacity: 1,
              }
            ],
            onChapterExit: [
              {
                layer: 'Pietonnier',
                opacity: 0.3,
              },
            ]
        },
        {
            id: 'TotalCommunesIntro',
            alignment: 'right',
            hidden: false,
            title: 'General Overview',
            image: '/Users/houda/Documents/MIND 3/Ateliers/Data/Coding/storytelling-main/src/images/MapEvolution.gif',
            description: 'The first level of our story concerns the total number of injured per km of road for each commune. Those show us quite quickly how unequal the situation is in the Region of Brussels.The communes of the Bruxelles-Capitale-Ixelles Police Zone are where the most injuries occur. This tendency was present before the Pedestrian Zone and stayed that way after. \n The South of Brussels with Uccle, Watermael-Boitsfort and Auderghem are the safest and this tendency was also present way before 2015. The numbers are also getting slightly better with time.',
            location: {
              center: [4.35397, 50.84169],
              zoom: 11.56,
              pitch: 15.65,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Communes21',
                opacity: 0.6,
              },
              {
                layer: 'Zones Police',
                opacity: 0.6,
              },
              {
                layer: 'Communes',
                opacity: 0.5,
              },
            ],
            onChapterExit: [
              {
                layer: 'Communes21',
                opacity: 0,
              },
            ]
        },
        {
            id: 'FocusBruCap',
            alignment: 'right',
            hidden: false,
            title: 'Bruxelles-Capitale-Ixelles',
            image: '',
            description: 'Now let’s focus of the Bruxelles-Capitale-Ixelles Police Zone (BruCap) with the commune of Bruxelles-Capitale and Ixelles. This zone seems to have the highest number of injured, ever since 2015. Why is that?',
            location: {
              center: [4.35397, 50.84169],
              zoom: 11.56,
              pitch: 15.65,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Bxl Cap Ixl',
                opacity: 0.6,
              }
            ],
            onChapterExit: [
              {
                layer: 'Bxl Cap Ixl',
                opacity: 0.1,
              },
              {
                layer: 'Zones Police',
                opacity: 0,
              },
              {
                layer: 'Communes',
                opacity: 0.1,
              }
            ]
        },
        {
            id: 'FocusBruCapAccidentsR20',
            alignment: 'right',
            hidden: false,
            title: 'R20',
            image: '',
            description: 'If we analyze the accidents and their localization (yellow circles), we can clearly see a correlation between the small Ring (R20) and the accidents with injuries. The R20 being located into the commune of Brussels-Capitale, it could partly explain the higher numbers. Zooming in on this R20 road, another interesting aspect of it would be the speeding allowed on it. Indeed, we can see how the roads with the most accidents are also the ones allowing a speed of 50+ km/h (orange roads). This shows us how speed an important factor is in provoking accidents with injuries.',
            location: {
              center: [4.37283, 50.84563],
              zoom: 13.69,
              pitch: 32.65,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Accidents',
                opacity: 1,
              },
            ],
            onChapterExit: [
              {
                layer: 'Ville30',
                opacity: 0.7,
              },
            ]
        },
        {
            id: 'FocusBruCapAccidentsPietonnier',
            alignment: 'right',
            hidden: false,
            title: '',
            image: '',
            description: 'However, speeding doesn’t explain everything. If we focus on the area inside the R20, we can still see how the roads connecting the north and south part of the R20 still have a lot of injuries on the road occurring. Those may be pushed aside by the pedestrian zone, but this clearly isn’t a situation for injuries on the road as those still occur on and next to the pedestrian zone.',
            location: {
              center: [4.36408, 50.84641],
              zoom: 14.36,
              pitch: 0.00,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [

            ],
            onChapterExit: [
              {
                layer: 'Ville30',
                opacity: 0,
              },
              {
                layer: 'Accidents',
                opacity: 0,
              },
              {
                layer: 'Bxl Cap Ixl',
                opacity: 0,
              },
              {
                layer: 'Pietonnier',
                opacity: 0,
              }
            ],
        },
        {
            id: 'FocusIxellesIntro',
            alignment: 'right',
            hidden: false,
            title: 'Ixelles',
            image: '',
            description: 'Now let’s focus on the second commune of the Police Zone BruCap, Ixelles. The geography of Ixelles is in itself very interesting as it’s being split in two by the Avenue Louise to allow easy access from Brussels city centre to the popular recreational area of the Bois de la Cambre. Ixelles is, in the BruCap Police Zone but also in the whole Region, where the most injuries occur.',
            location: {
              center: [4.39838, 50.81769],
              zoom: 13.38,
              pitch: 21.00,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Ixelles',
                opacity: 0.5,
              },
            ],
            onChapterExit: [
              {
                layer: 'Accidents',
                opacity: 1,
              },
              {
                layer: 'Ixelles',
                opacity: 0.1,
              },
            ]
        },
        {
            id: 'FocusIxellesAccidents',
            alignment: 'fully',
            hidden: false,
            title: '',
            image: '/Users/houda/Documents/MIND 3/Ateliers/Data/Coding/storytelling-main/src/images/BarChartEvolutionIxelles.gif',
            description: 'We can see how Ixelles (red bar on this barchart) slowly evolved as one of the most dangerous during those 5 past years. The situation only got worse in 2021 with 438 injured, 16 heavily. This makes the roads of this commune one of the most dangerous in Brussels. But what explains those numbers?',
            location: {
              center: [4.39838, 50.81769],
              zoom: 13.38,
              pitch: 21.00,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Ville30',
                opacity: 0.7,
              },
                        ],
            onChapterExit: []
        },
        {
            id: 'FocusIxellesAccidentsZoom',
            alignment: 'right',
            hidden: false,
            title: '',
            image: '',
            description: 'We see quite a lot of long important roads going through this small elongated commune. Especially on the right part.The first thing we can see is that the number of accidents seem to rise the more we near the R20. Avenue Louise (situation in de commune of Brussels), Chaussée d’Ixelles and Rue de Trone being the most important vectors of accidents. Besides the Avenue Louise, those roads have a speed limit of 30, so speed can’t explain this rise.',
            location: {
              center: [4.37792, 50.82762],
              zoom: 14.64,
              pitch: 49.50,
              bearing: -8.80
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'FocusIxellesJacques',
            alignment: 'right',
            hidden: false,
            title: '',
            image: '',
            description: 'The speed limit may, however, partly explain the cluster of accidents we find on the Boulevard General Jacques that crosses through the lower part of Ixelles.',
            location: {
              center: [4.39394, 50.82078],
              zoom: 14.38,
              pitch: 21.00,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'FocusIxellesR21',
            alignment: 'right',
            hidden: false,
            title: '',
            image: '',
            description: 'This Boulevard is part of the R21 (Grande Ceinture) that connects Ixelles with Etterbeek and Auderghem. With a speed limit of 50km/h this very crucial road with a heavy flow of vehicles can only be accident prone.',
            location: {
              center: [4.41880, 50.83978],
              zoom: 13.21,
              pitch: 32.50,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [],
            onChapterExit: []
        },
        {
            id: 'FocusIxellesFlagey',
            alignment: 'right',
            hidden: false,
            title: 'Flagey',
            image: '',
            description: 'Interestingly, the place that comes to the mind of the locals when in comes to Ixelles and traffic is place Flagey. It’s often described as a very problematic intersection of the commune. The speed limit being 30km/h all around this zone, speed would explain the difficulties and number of accidents in this area. The first hypothesis would be the connexion it forms. Place Flagey is an important intersection between the Rue de Trone / Avenue de la Couronne and the tunnels of the Avenue Louise. The flow of vehicles going through around Place Flagey is therefore heavy. Its complexity makes it also difficult to navigate, which can explain some accidents. ',
            location: {
              center: [4.37778, 50.82766],
              zoom: 15.40,
              pitch: 34.50,
              bearing: 0.00
            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'flagey',
                opacity: 1,
              },
            ],
            onChapterExit: [
              {
                layer: 'Ixelles',
                opacity: 0,
              },
              {
                layer: 'Ville30',
                opacity: 0,
              },
              {
                layer: 'flagey',
                opacity: 0,
              },

            ]
        },
        {
            id: 'Conclusion',
            alignment: 'fully',
            hidden: false,
            title: 'Conclusion',
            image: '',
            description: 'Flagey is therefore a place that tells us a story that can be extrapolated all for all the region. When navigating through the accidents in Brussels, not only speed but traffic regulation and structure may play a crucial role in reducing the number of accidents. A global view is of great importance. One change in one street or one commune may just push the problem away to another, as the City Center’s Pietonnier shows us. A further analyze of the evolution of traffic flow, the interconnectivity between the problematic areas and a holistic approach in problem solving is therefore crucial.',
            location: {
              center: [4.35397, 50.84169],
              zoom: 12,
              pitch: 0.00,
              bearing: 0.00

            },
            mapAnimation: 'flyTo',
            rotateAnimation: false,
            callback: '',
            onChapterEnter: [
              {
                layer: 'Accidents',
                opacity: 0,
              },
              {
                layer: 'Zones Police',
                opacity: 0,
              },

            ],
            onChapterExit: []
        },
    ]
}
;
